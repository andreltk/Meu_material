void criaHeap(int *vet, int i, int f);
void heapSort(int *vet, int N);
