//Feito por André Luiz Teixeira Kohlrausch 
//Cabeçalho da biblioteca Cilindro Reto

#include"cilindro_r.h"


cilindro_reto * aloca_cilindro_r(){
    
    cilindro_reto* a1;
    
    a1 = (cilindro_reto*)malloc(sizeof(cilindro_reto));
    
    if(a1==NULL){
        printf("\nErro na alocação!\n");
        return NULL;
    }
    
    else
        return a1;
    
}

void libera_cilindro_r (cilindro_reto* cilindro_r){
    
    free(cilindro_r);
    
    cilindro_r = NULL;
    
}
float area_base_cr(cilindro_reto* cilindro_r){
    
    float r;
    
    r = cilindro_r->raio;
    
    return (r * r) * PI;
    
}
float volume(cilindro_reto* cilindro_r){
    
    float altura;
    
    altura = cilindro_r->altura;
    
    return area_base_cr(cilindro_r) * altura;
    
}
