//Feito por André Luiz Teixeira Kohlrausch

#include"cilindro_r.h"

int main(){
    
    cilindro_reto* cilindro_r;
    
    cilindro_r = aloca_cilindro_r();
    
    printf("Digite o raio:\n");
    scanf("%f",&cilindro_r->raio);
    
    printf("Digite a altura:\n");
    scanf("%f",&cilindro_r->altura);
    
    printf("Altura:\t%f\n",cilindro_r->altura);
    printf("Raio:\t%f\n",cilindro_r->raio);
    printf("Área da base:\t%f\n",area_base_cr(cilindro_r));
    printf("Volume:\t%f\n",volume(cilindro_r));
    
    libera_cilindro_r(cilindro_r);
    
    return 0;
}
