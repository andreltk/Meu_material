//Feito por André Luiz Teixeira Kohlrausch 
//Cabeçalho da biblioteca Cilindro Reto

#define PI 3.141592

#include<stdio.h>
#include<stdlib.h>

typedef struct{
    
    float raio;
    float altura;
    
}cilindro_reto;

cilindro_reto * aloca_cilindro_r();

void libera_cilindro_r (cilindro_reto* cilindro_r);

float area_base_cr(cilindro_reto* cilindro_r);

float volume(cilindro_reto* cilindro_r);
