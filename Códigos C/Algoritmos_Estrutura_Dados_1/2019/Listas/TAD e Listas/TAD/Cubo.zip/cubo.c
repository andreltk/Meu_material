//Feito por André Luiz Teixeira Kohlrausch

/*
 * Código fonte da biblioteca Cubo
 * 
 */

#include"cubo.h"

Cubo * aloca_cubo(){
    
    Cubo* cubo;
    
    cubo = (Cubo*) malloc(sizeof(Cubo));
    
    if(cubo == NULL){
        
        printf("\nErro na alocação!\n");
        return NULL;
        
    }
    
    else
        return cubo;
}

void libera_cubo(Cubo* cubo){
    
    free (cubo);
    cubo = NULL;
    return;
    
    
}


float calcula_perimetro(Cubo* cubo){
    
    
    float aresta;


    aresta = cubo->aresta;
    
    return aresta * 12;
}

float calcula_area(Cubo* cubo){
    
    float aresta;

       
    aresta = cubo->aresta;
    
    return (aresta * aresta) * 6.0;
    
}

float calcula_volume(Cubo* cubo){
    
    float aresta;
    
    aresta = cubo->aresta;
    
    return (aresta * aresta * aresta);
    
}
