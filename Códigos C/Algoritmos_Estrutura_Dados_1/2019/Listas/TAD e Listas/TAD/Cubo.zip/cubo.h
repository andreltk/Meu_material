//Feito por André Luiz Teixeira Kohlrausch
/*
 * Cabeçalho da biblioteca Cubo
 * 
 */

#include<stdio.h>
#include<stdlib.h>

typedef struct {
    
    float aresta;
    
}Cubo;

//Aloca memória necessária para a Struct Cubo 
Cubo * aloca_cubo();

void libera_cubo(Cubo* cubo);

float calcula_perimetro(Cubo* cubo);

float calcula_area(Cubo* cubo);

float calcula_volume(Cubo* cubo);




