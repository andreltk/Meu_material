//Feito por André Luiz T. Kohlrausch

//Arquvo fonte da biblioteca esfera

#include"esfera.h"

esfera* aloca_esfera(){
    
    esfera* a1;
    
    a1=(esfera*)malloc(sizeof(esfera));
    
    if(a1 == NULL)
        printf("Erro na alocação!\n");
    
    return a1;
    
}
void libera_esfera(esfera* esfera_1){

    free(esfera_1);
    esfera_1 = NULL;
}   

float area_esfera(esfera* esfera_1){
    
    float raio;
    
    raio = esfera_1->raio;
    
    return 4 * (raio * raio) * PI;
    
}

float volume_esfera(esfera* esfera_1){
    
    float raio;
    
    raio = esfera_1->raio;
    
    return (4 * (raio * raio) * PI) / 3.0;
    
}

