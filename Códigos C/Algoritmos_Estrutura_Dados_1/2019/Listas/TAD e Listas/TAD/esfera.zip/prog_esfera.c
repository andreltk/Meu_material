//Feito por André Luiz T. Kohlrausch

/*
 * TAD: esfera
 * 
 * Desenvolva um TAD que represente uma esfera. Inclua as 
 * funções de inicialização necessárias e as
 * operações que retornem: (a) o raio; (b) a área; e (c) o 
 * volume. 
 */

#include"esfera.h"

int main(){
    
    esfera* esfera_1;
    
    esfera_1 = aloca_esfera();
    
    printf("Digite o raio:\n");
    scanf("%f",&esfera_1->raio);
    
    printf("Raio:\t%.3f\n",esfera_1->raio);
    
    printf("Área:\t%.3f\n",area_esfera(esfera_1));
    
    printf("Volume:\t%.3f\n",volume_esfera(esfera_1));
    
    libera_esfera(esfera_1);
    
}
