//Feito por André Luiz T. Kohlrausch

//Cabeçalho da biblioteca esfera

#include<stdio.h>
#include<stdlib.h>

#define PI 3.141592

typedef struct{
    
    float raio;
    
}esfera;

esfera* aloca_esfera();

void libera_esfera(esfera* esfera_1);

float area_esfera(esfera* esfera_1);

float volume_esfera(esfera* esfera_1);

