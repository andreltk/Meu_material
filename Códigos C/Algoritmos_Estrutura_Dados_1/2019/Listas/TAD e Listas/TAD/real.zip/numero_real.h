//Feito por André Luiz Teixeira Kohlrausch 

//Cabeçalho biblioteca Número Real

/* Observação:
 * 
 * Desconhecido o tipo de retorno das funções, portanto será 
 * usado tipo VOID e será imprimido diretamente nas mesmas.
 *
 */

#include<stdio.h>
#include<stdlib.h>

typedef struct{
    
    int inteiro;
    int decimal;
}n_real;

n_real* aloca_real();

void libera_real(n_real* real);

void soma_reais(n_real* real_1,n_real* real_2);

void multiplica_reais(n_real* real_1,n_real* real_2);

float converte_real_float(n_real* real);
