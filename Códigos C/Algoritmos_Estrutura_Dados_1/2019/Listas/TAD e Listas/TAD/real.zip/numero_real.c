//Feito por André Luiz Teixeira Kohlrausch 

//Código fonte da biblioteca Número Real

#include"numero_real.h"

n_real* aloca_real(){
    
    n_real* a1;
    
    a1=(n_real*)malloc(sizeof(n_real));
    
    if(a1 == NULL)
        printf("Erro na alocação!\n");
    
    return a1;
    
}

void libera_real(n_real* real){
    
    free (real);
    
    real = NULL;
    
}

void soma_reais(n_real* real_1,n_real* real_2){
    
    float auxiliar_1,auxiliar_2;
    
    auxiliar_1 = converte_real_float(real_1);
    auxiliar_2 = converte_real_float(real_2);
    
    printf("%f + %f = %f\n",auxiliar_1,auxiliar_2,(auxiliar_1 + auxiliar_2));
    
}

void multiplica_reais(n_real* real_1,n_real* real_2){
    
    float auxiliar_1,auxiliar_2;
    
    auxiliar_1 = converte_real_float(real_1);
    auxiliar_2 = converte_real_float(real_2);
    
    printf("%f x %f = %f\n",auxiliar_1,auxiliar_2,(auxiliar_1 * auxiliar_2));
    
    
}

float converte_real_float(n_real* real){
    
    float auxiliar_1,auxiliar_2;
    
    auxiliar_1 = real->inteiro;
    auxiliar_2 = real->decimal;
    
    if(auxiliar_2 < 10)
        auxiliar_2 /= 10.0;
    
    else if(auxiliar_2 < 100)
        auxiliar_2 /= 100.0;
    
    else if(auxiliar_2 < 1000)
        auxiliar_2 /= 1000.0;
    
    else if(auxiliar_2 < 10000)
        auxiliar_2 /= 10000.0;
    
    else if(auxiliar_2 < 100000)
        auxiliar_2 /= 100000.0;
   
    else if(auxiliar_2 < 1000000)
        auxiliar_2 /= 1000000.0;
    
    return auxiliar_1 + auxiliar_2;
    
}

