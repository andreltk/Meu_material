#include"BLista.h"

int main(){
    
    int escolha,verifica,id,contador;
    Lista * l1;
    Item * auxiliar;
    l1=NULL;
    
    
    system("clear");
    
    
    
    l1=criaLista();
    
    if(l1 != NULL){
        system("clear");
        
        printf("\n\n\nBem vindo\n\n\n");  
        
        
    }
    else{
        printf("\nNão foi possível criar a lista\n");
        printf("\nTente novamente\n");
        return 0;
    }
    
    
    
    
    
    
    escolha = -1;
    
    
    while(escolha != 0){
        //  
        printf("\n========================\n");
        printf("\nEscolha uma opção:\n");
        
        printf("\n\t1-Inserir item");
        printf("\n\t2-Remover item");
        printf("\n\t3-Buscar  item");
        printf("\n\t4-Imprimir lista");
        printf("\n\t5-Apagar lista");
        printf("\n\t0-Sair");
        
        printf("\n========================\n");
        
        printf("------->");
        
        scanf("%d",&escolha);
        
        switch(escolha){
            
            /////////////////////////////////////////////////////////////////////////////
            case 1:
                
                verifica=insereItem(l1);
                
                if(verifica == -1){
                    printf("ERRO!\n");
                    return 0;
                }
                else
                    system("clear");
                
                
                auxiliar = (Item*) l1->inicio;
                
                while(1){
                    
                    if(auxiliar->proximo == l1->inicio){
                        
                        printf("\nInsira informações:\n");
                        
                        printf("ID --> ");
                        
                        scanf("%d",&auxiliar->identidade);
                        
                        printf("\nConsumo em Watts--> ");
                        
                        scanf("%d",&auxiliar->consumo);
                        
                        printf("\nAno de fabricação--> ");
                        
                        scanf("%d",&auxiliar->ano);
                        
                        printf("\nCor do item--> ");
                        
                        scanf("\n%[^\n]s",auxiliar->cor);
                        
                        printf("\nFabricante--> ");
                        
                        scanf("\n%[^\n]s",auxiliar->marca);
                        
                        printf("\n========================\n");
                        
                        printf("\nAdicionado com sucesso!\n\n");
                        
                        break;
                        
                    }
                    
                    
                    else{
                        auxiliar=(Item*)auxiliar->proximo;
                    }
                }
                break;
                /////////////////////////////////////////////////////////////////////////////
                
                case 2:
                    
                    system("clear");
                    printf("\nDigite o ID do item que deseja excluir\n\n");
                    
                    scanf("%d",&id);
                    
                    verifica=removeItem(l1,id);
                    
                    if(verifica == 1){
                        
                        printf("\n\nItem removido!\n\n");
                        break;
                        
                    }
                    
                    else if(verifica == 2){
                        printf("\n\nERRO!\nNão foi possível remover!\n");
                        printf("ID inexistente\n");
                        break;
                    }
                    
                    else{
                        printf("\n\nERRO!\nNão foi possível remover!\n");
                        printf("ID inexistente\n");
                        break;
                    }
                    /////////////////////////////////////////////////////////////////////////////
                case 3:
                    system("clear");
                    printf("\nDigite o ID do item que procura\n\n");
                    
                    scanf("%d",&id);
                    
                    auxiliar = Busca(l1,id);
                    
                    if(auxiliar == NULL || l1->quantidade == 0){
                        system("clear");
                        printf("\nLista Vazia\n\n");
                        break;
                    }
                    
                    if(auxiliar == NULL){
                        printf("\n\nERRO!\nItem não encontrado!\n");
                        printf("ID inexistente\n");
                        break;
                    }
                    
                    system("clear");
                    
                    printf("\n----------------------\n");
                    
                    printf("ID = %d\n",auxiliar->identidade);
                    
                    printf("Consumo = %d\n",auxiliar->consumo);
                    
                    printf("Ano = %d\n",auxiliar->ano);
                    
                    printf("Cor = %s\n",auxiliar->cor);
                    
                    printf("Marca = %s\n",auxiliar->marca);
                    
                    printf("\n----------------------\n");
                    
                    break;
                    
                    
                    /////////////////////////////////////////////////////////////////////////////
                case 4:
                    
                    auxiliar=(Item*) l1->inicio;
                    
                    if(auxiliar == NULL || l1->quantidade == 0){
                        system("clear");
                        printf("\nLista Vazia\n\n");
                        break;
                    }
                    
                    system("clear");
                    
                    printf("\n========================\n");
                    
                    for(contador = 0;contador < l1->quantidade;contador++){
                        
                        printf("\n----------------------\n");
                        
                        printf("ID = %d\n",auxiliar->identidade);
                        
                        printf("Consumo = %d\n",auxiliar->consumo);
                        
                        printf("Ano = %d\n",auxiliar->ano);
                        
                        printf("Cor = %s\n",auxiliar->cor);
                        
                        printf("Marca = %s\n",auxiliar->marca);
                        
                        printf("\n----------------------\n");
                        
                        
                        /*
                         *                        if(auxiliar->proximo == l1->inicio){
                         *                            break;
                    } */
                        
                        auxiliar=(Item*) auxiliar->proximo;
                        
                    }
                    
                    printf("\n========================\n");
                    break;
                    /////////////////////////////////////////////////////////////////////////////
                case 5:

                    system("clear");
                    printf("\nRealmente deseja excluir a lista e sair?\n\n");
                    printf("\n1 = Sim / 2 = Não\n");
                    printf("------->");
        
                    scanf("%d",&verifica);

                    if(verifica == 1 ){
                        
                        apagaLista(l1);
                        
                        return 0;
                    }
                    else 
                        break;
                    /////////////////////////////////////////////////////////////////////////////
                case 0:
                    return 0;
                    /////////////////////////////////////////////////////////////////////////////
                default:
                    system("clear");
                    printf("\nOpção Inválida!\n\n");
                    break;
                    
                    
        }
    }
}




